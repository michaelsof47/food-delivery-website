import "../scripts/component/register-app.js";

function main()
{
	const message_value = (message = "Silahkan hubungi kami untuk lebih lanjut") =>
	{
		alert(message);
	}

	const btn_order = document.querySelector(".order");
	btn_order.addEventListener("click",() =>
	{
		message_value("Fitur ini akan tersedia dalam beberapa minggu kedepan");
	});

	const btn_login = document.querySelector(".login");
	btn_login.addEventListener("click",() =>
	{
		message_value("Fitur ini akan tersedia dalam beberapa hari lagi");
	})

	const btn_subscribe = document.querySelector(".email-subscribe-submit");
	btn_subscribe.addEventListener("click",() =>
	{
		const edt_subscribe = document.querySelector(".email-subscribe");
		checkEmailSubscribe("",edt_subscribe)
		.then(message_value =>
			{
				alert(message_value);
				document.querySelector(".email-subscribe").value = "";
			})
		.catch(message_value =>
			{
				alert(message_value);
			})
	})

	const registerBar = document.querySelector("register-bar");

	EmailForm.clickEvent = alert(message_value);

}

export default main;