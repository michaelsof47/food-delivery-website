import main from "./scripts/homepage.js";
import "./styles/homepage.css";
import "./scripts/component/register-app.js";
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/js/bootstrap.min.js";
import "jquery/dist/jquery.min.js";
import "font-awesome/css/font-awesome.min.css";

document.addEventListener("DOMContentLoaded", main);