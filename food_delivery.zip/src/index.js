import main from "./scripts/homepage.js";
import "./styles/homepage.css";

document.addEventListener("DOMContentLoaded",main);