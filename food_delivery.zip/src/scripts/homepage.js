function checker(value, email_input)
{
	return new Promise((resolve,reject) =>
	{
		if(email_input !== "" && email_input !== null)
		{
			value = alert("Terima kasih atas partisipasi anda untuk mengisi email di bawah ini, Mohon ditunggu 4-5 hari kedepan");
			resolve(value);
		}
		else
		{
			value = alert("Gagal Masuk");
			reject(value);
		}
	})
}

function main()
{
	const message_value = (message = "Silahkan hubungi kami untuk lebih lanjut") =>
	{
		alert(message);
	}

	const btn_order = document.querySelector(".order");
	btn_order.addEventListener("click",() =>
	{
		message_value("Fitur ini akan tersedia dalam beberapa minggu kedepan");
	});

	const btn_login = document.querySelector(".login");
	btn_login.addEventListener("click",() =>
	{
		message_value("Fitur ini akan tersedia dalam beberapa hari lagi");
	})

	const btn_submit = document.querySelector(".btn_email");
	btn_submit.addEventListener("click", () =>
	{
		let email_input = document.querySelector("#email_user").value;
		checker("",email_input)
		.then((message_value = "berhasil") =>
			{
				console.log(message_value)
			})
		.catch((error = "gagal") =>
			{
				console.log(error);
			})
	})

}

export default main;